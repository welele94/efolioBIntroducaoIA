
# eFólio B — Introdução à Inteligência Artificial

Este projeto é uma **evolução do eFólio A**.

- No **eFólio A**, o problema era de procura clássica com um único agente.
- No **eFólio B**, o problema passa a **procura adversa**, com dois agentes (A e V) a competir por capturas de peões pretos.

## Estrutura

- `main.py`: ciclo principal do jogo e impressão do resultado.
- `board.py`: parsing do tabuleiro, coordenadas e utilitários de impressão.
- `game_state.py`: classe `GameState`, aplicação de jogadas e condições de terminal.
- `moves.py`: geração de movimentos legais (rei, capturas em peça, saída da peça e pass).
- `evaluation.py`: função de avaliação com pesos ajustáveis.
- `minimax.py`: Minimax com poda alfa-beta e ordenação simples de jogadas.

## Como correr

```bash
python main.py
```

## Minimax, alfa-beta e avaliação

O agente escolhe jogadas com Minimax de profundidade limitada.

- **Minimax**: modela o jogo como alternância entre jogador maximizador (A) e minimizador (V).
- **Poda alfa-beta**: corta ramos que não podem melhorar o resultado, reduzindo custo de pesquisa.
- **Função de avaliação**: combina diferença de capturas, mobilidade e proximidade a peões pretos.

A base foi feita para ser simples de evoluir, sobretudo na heurística (`evaluation.py`) e no ajuste de profundidade (`main.py`).
