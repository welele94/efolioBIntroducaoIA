"""Entry point to simulate one full adversarial game."""

import csv

from board import print_board
from game_state import create_initial_state
from minimax import minimax_decision

MAX_DEPTH = 3
PRINT_EACH_TURN = True
RESULTS_CSV = "resultados.csv"


def render_with_agents(state):
    board = [row[:] for row in state.board]
    ar, ac = state.a_pos
    vr, vc = state.v_pos
    board[ar][ac] = "A"
    board[vr][vc] = "V"
    return board


def main():
    state = create_initial_state()
    history = []

    with open(RESULTS_CSV, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["acao", "jogador", "tipo", "origem", "destino", "notacao", "capturas_A", "capturas_V"])

        if PRINT_EACH_TURN:
            print("Estado inicial")
            print_board(render_with_agents(state))

        while not state.is_terminal():
            current_player = state.current_player
            move = minimax_decision(state, depth=MAX_DEPTH)
            if move is None:
                break

            history.append(f"{current_player}: {move.notation}")
            state = state.apply_move(move)

            writer.writerow([
                state.action_count,
                current_player,
                move.move_type,
                move.from_pos,
                move.to_pos,
                move.notation,
                state.a_captures,
                state.v_captures,
            ])

            if PRINT_EACH_TURN:
                print(f"\nAção {state.action_count}: {history[-1]}")
                print_board(render_with_agents(state))

        writer.writerow([])
        writer.writerow(["resumo_final"])
        writer.writerow(["capturas_A", state.a_captures])
        writer.writerow(["capturas_V", state.v_captures])
        writer.writerow(["total_acoes", state.action_count])
        writer.writerow(["vencedor", state.get_winner()])

    print("\n=== Resultado final ===")
    print("Sequência de jogadas:")
    for idx, item in enumerate(history, start=1):
        print(f"{idx:02d}. {item}")

    print(f"\nCapturas A (verde): {state.a_captures}")
    print(f"Capturas V (vermelho): {state.v_captures}")
    print(f"Total de ações: {state.action_count}")
    print(f"Vencedor: {state.get_winner()}")
    print(f"Resultados guardados em: {RESULTS_CSV}")


if __name__ == "__main__":
    main()
